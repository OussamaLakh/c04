/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: olakhlil <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/01 14:38:08 by olakhlil          #+#    #+#             */
/*   Updated: 2025/09/01 16:59:30 by olakhlil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int	*arr;
	int	rang;
	int	i;

	rang = (max - min);
	i = 0;
	if (max < min)
		arr = NULL;
	else
		arr = malloc(sizeof(int) * (rang));
	if (arr == NULL)
		return (0);
	else
	{
		while (min < max)
		{
			arr[i] = min;
			i++;
			min++;
		}
	}
	return (arr);
}
/*
#include <stdio.h>

int main ()
{
int	min = -2;
int	max = 4;
int	i=0;
int	rang = max - min;

int	*arr;
arr = ft_range(min , max);
while (i < rang)
{
	printf("%d", arr[i]);
	i++;
}
printf("\n");
}*/
