/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: olakhlil <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/28 13:52:21 by olakhlil          #+#    #+#             */
/*   Updated: 2025/08/28 16:02:58 by olakhlil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_factorial(int nb)
{
	int	i;

	if (nb < 0)
		return (0);
	if (nb == 0)
	{
		return (1);
	}
	i = nb - 1;
	while (i > 1)
	{
		nb *= i;
		i--;
	}
	return (nb);
}
/*
 #include <stdio.h>
int main ()
{
	int nb = -5;
	printf("fact of nb = %d\n", ft_iterative_factorial(nb));
}*/
