/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: olakhlil <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/28 17:00:29 by olakhlil          #+#    #+#             */
/*   Updated: 2025/08/28 18:01:24 by olakhlil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_recursive_power(int nb, int power)
{
	if (power < 0)
		return (0);
	if (power == 0)
	{
		return (1);
	}
	return (nb * ft_recursive_power(nb, (power - 1)));
}
/*
#include <stdio.h>
int main ()
{
	int	nb=-2;
	int power=8;
	printf("res= %d\n", ft_recursive_power(nb, power));
}*/
