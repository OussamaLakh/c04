/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: olakhlil <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/01 17:46:56 by olakhlil          #+#    #+#             */
/*   Updated: 2025/09/01 20:29:19 by olakhlil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_ultimate_range(int **range, int min, int max)
{
	int	i;
	int	rlen;

	if (min >= max)
	{
		*range = NULL;
		return (-1);
	}
	else
	{
		rlen = max - min;
		*range = malloc(sizeof(int) * rlen);
		if (*range == NULL)
			return (0);
	}
	i = 0;
	while (min < max)
	{
		(*range)[i] = min;
		i++;
		min++;
	}
	return (rlen);
}
/*
#include <stdio.h>

int main(void)
{
    int *arr;
    int size;
    int i;

    // --------------------------
    // Test Case 1: Normal range
    printf("Test 1: Normal range (3, 7)\n");
    size = ft_ultimate_range(&arr, 3, 7);
    printf("size = %d\narr = ", size);
    for (i = 0; i < size; i++)
        printf("%d ", arr[i]);
    printf("\n\n");
    free(arr);

    // --------------------------
    // Test Case 2: min >= max (empty range)
    printf("Test 2: min >= max (10, 5)\n");
    size = ft_ultimate_range(&arr, 10, 5);
    printf("size = %d\narr = %p\n\n", size, (void*)arr);

    printf("Test 3: min == max (5, 5)\n");
    size = ft_ultimate_range(&arr, 5, 5);
    printf("size = %d\narr = %p\n\n", size, (void*)arr);

    // --------------------------
    // Test Case 3: Single element range
    printf("Test 4: Single element range (7, 8)\n");
    size = ft_ultimate_range(&arr, 7, 8);
    printf("size = %d\narr = ", size);
    for (i = 0; i < size; i++)
        printf("%d ", arr[i]);
    printf("\n\n");
    free(arr);

    // --------------------------
    // Test Case 4: Negative numbers
    printf("Test 5: Negative range (-3, 2)\n");
    size = ft_ultimate_range(&arr, -3, 2);
    printf("size = %d\narr = ", size);
    for (i = 0; i < size; i++)
        printf("%d ", arr[i]);
    printf("\n\n");
    free(arr);

    // --------------------------
    // Test Case 5: Large range (0, 10) - reduced for demo
    printf("Test 6: Large range (0, 10)\n");
    size = ft_ultimate_range(&arr, 0, 10);
    printf("size = %d\narr = ", size);
    for (i = 0; i < size; i++)
        printf("%d ", arr[i]);
    printf("\n\n");
    free(arr);

    return 0;
}*/
