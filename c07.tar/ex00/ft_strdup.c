/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: olakhlil <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/01 13:49:05 by olakhlil          #+#    #+#             */
/*   Updated: 2025/09/01 15:12:08 by olakhlil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		i++;
	}
	return (i);
}

char	*ft_strdup(char *src)
{
	int		index;
	int		lent;
	char	*dest;

	index = 0;
	lent = (ft_strlen(src));
	dest = malloc(sizeof(char) * (lent + 1));
	if (dest == NULL)
		return (0);
	else
	{
		while (src[index] != '\0')
		{
			dest[index] = src[index];
			index++;
		}
		dest[index] = '\0';
	}
	return (dest);
}
/*
#include <stdio.h>
int main ()
{
	char *str="hello world!";
	printf("%s\n", ft_strdup(str));
}*/
