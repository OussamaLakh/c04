/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: olakhlil <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/25 23:37:53 by olakhlil          #+#    #+#             */
/*   Updated: 2025/08/27 18:07:49 by olakhlil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putstr(char *str)
{
	if (*str)
	{
		write (1, str, 1);
	}
	else
	{
		return ;
	}
	ft_putstr(str + 1);
}
/*
int main ()
{
	char *s="hello world!";
	ft_putstr(s);
}*/
