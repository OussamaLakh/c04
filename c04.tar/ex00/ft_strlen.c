/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: olakhlil <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/25 23:20:47 by olakhlil          #+#    #+#             */
/*   Updated: 2025/08/25 23:36:14 by olakhlil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strlen(char *str)
{
	char	*pt;

	pt = str;
	while (*pt)
	{
		pt++;
	}
	return (pt - str);
}
/*
#include <stdio.h>

int main ()
{
	char  *s="123456";
	printf("lent of s is: %d\n", ft_strlen(s));
}*/
