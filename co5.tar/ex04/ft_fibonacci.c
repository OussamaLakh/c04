/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_fibonacci.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: olakhlil <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/28 18:09:05 by olakhlil          #+#    #+#             */
/*   Updated: 2025/08/28 19:10:10 by olakhlil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_fibonacci(int index)
{
	if (index < 0)
		return (-1);
	if (index == 0)
		return (0);
	if (index == 1)
		return (1);
	return (ft_fibonacci(index - 1)
		+ ft_fibonacci(index - 2));
}
/*
#include <stdio.h>
int main ()
{
	// Negative test
    printf("ft_fibonacci(-5) = %d (expected -1)\n", ft_fibonacci(-5));

    // Base cases
    printf("ft_fibonacci(0) = %d (expected 0)\n", ft_fibonacci(0));
    printf("ft_fibonacci(1) = %d (expected 1)\n", ft_fibonacci(1));

    // Small values
    printf("ft_fibonacci(2) = %d (expected 1)\n", ft_fibonacci(2));
    printf("ft_fibonacci(3) = %d (expected 2)\n", ft_fibonacci(3));
    printf("ft_fibonacci(4) = %d (expected 3)\n", ft_fibonacci(4));
    printf("ft_fibonacci(5) = %d (expected 5)\n", ft_fibonacci(5));
    printf("ft_fibonacci(6) = %d (expected 8)\n", ft_fibonacci(6));
    printf("ft_fibonacci(7) = %d (expected 13)\n", ft_fibonacci(7));
    printf("ft_fibonacci(8) = %d (expected 21)\n", ft_fibonacci(8));
    printf("ft_fibonacci(9) = %d (expected 34)\n", ft_fibonacci(9));
    printf("ft_fibonacci(10) = %d (expected 55)\n", ft_fibonacci(10));

    // Medium values
    printf("ft_fibonacci(15) = %d (expected 610)\n", ft_fibonacci(15));
    printf("ft_fibonacci(20) = %d (expected 6765)\n", ft_fibonacci(20));

    printf("ft_fibonacci(30) = %d (expected 832040)\n", ft_fibonacci(30));
    printf("ft_fibonacci(40) = %d (expected 102334155)\n", ft_fibonacci(40));

    return (0);
}*/
