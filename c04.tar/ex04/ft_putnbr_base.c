/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: olakhlil <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/26 20:45:43 by olakhlil          #+#    #+#             */
/*   Updated: 2025/08/27 17:16:37 by olakhlil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_strcmp(char *base, char *s2)
{
	if (!*base)
		return (1);
	while (*base && *base == *s2)
	{
		base++;
		s2++;
	}
	return (*base - *s2);
}

int	ft_sheckbase(char *base)
{
	char	*dec;
	char	*hex;
	char	*bin;
	char	*oct;

	dec = "0123456789";
	hex = "0123456789ABCDEF";
	bin = "01";
	oct = "poneyvif";
	if (ft_strcmp(base, dec) == 0)
		return (10);
	else if (ft_strcmp(base, hex) == 0)
		return (16);
	else if (ft_strcmp(base, bin) == 0)
		return (2);
	else if (ft_strcmp(base, oct) == 0)
		return (8);
	else
		return (0);
}

void	ft_putnbr_base(int nbr, char *base)
{
	int	i;
	unsigned int	n;

	i = ft_sheckbase(base);
	n = (unsigned int )nbr;
	if (i == 0)
		return ;
	if (nbr < 0)
	{
		write(1, "-", 1);
		n = (unsigned int)(-nbr);
	}
	if (n < (unsigned int)i)
	{
		write(1, &base[n], 1);
	}
	else if (n >= (unsigned int)i)
	{
		ft_putnbr_base((n / i), base);
		ft_putnbr_base((n % i), base);
	}
}
/*
int main ()
{
char	base1[] = "0123456789ABCDEF";
char    base2[] = "01";
char    base3[] = "013";
int	nbr = 2147;

	ft_putnbr_base(nbr, base1);
		write(1, "\n", 1);
	ft_putnbr_base(nbr, base2);
		write(1, "\n", 1);
	ft_putnbr_base(nbr, base3);
		write(1, "\n", 1);

}*/
