/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: olakhlil <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/01 20:38:11 by olakhlil          #+#    #+#             */
/*   Updated: 2025/09/02 14:17:52 by olakhlil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str [i])
	{
		i++;
	}
	return (i);
}

char	*ft_strcat(char *join, char *str)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	while (join[i])
	{
		i++;
	}
	while (str[j])
	{
		join[i] = str[j];
		i++;
		j++;
	}
	join[i] = '\0';
	return (join);
}

int	ft_sumlens(int size, char *sep, char **str)
{
	int	z;
	int	strsl;
	int	sepl;
	int	suml;

	z = 0;
	strsl = 0;
	while (z < size)
	{
		strsl += ft_strlen(*str);
		str++;
		z++;
	}
	sepl = ft_strlen(sep);
	suml = strsl + (sepl * (size - 1));
	return (suml);
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	int		i;
	int		suml;
	char	*join;

	suml = ft_sumlens(size, sep, strs);
	join = malloc(sizeof(char) * (suml + 1));
	if (join == NULL)
		return (0);
	else
	{
		join[0] = '\0';
		if (size == 0)
			return (join);
		i = 0;
		while (i < size)
		{
			join = ft_strcat(join, strs[i]);
			if (i < size -1)
				join = ft_strcat(join, sep);
			i++;
		}
	}
	return (join);
}
/*
#include <stdio.h>

int main(void)
{
    char *result;
    char *words1[] = {"Hello", "world", "42"};
    char *words2[] = {"one"};
    char *words3[] = {"A", "B", "C", "D"};

    // Test 1: Normal join
    result = ft_strjoin(3, words1, " ");
    printf("Test 1: %s\n", result);
    free(result);

    // Test 2: Only one string
    result = ft_strjoin(1, words2, ", ");
    printf("Test 2: %s\n", result);
    free(result);

    // Test 3: Multiple with separator
    result = ft_strjoin(4, words3, "-_");
    printf("Test 3: %s\n", result);
    free(result);

    // Test 4: Empty size
    result = ft_strjoin(0, words1, " ");
    printf("Test 4: '%s'\n", result); // should print an empty string
    free(result);

    return 0;
}*/
