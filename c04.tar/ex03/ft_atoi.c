/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: olakhlil <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/26 15:01:37 by olakhlil          #+#    #+#             */
/*   Updated: 2025/08/26 20:37:27 by olakhlil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_atoi(char *str)
{
	int	sign;
	int	res;

	sign = 1;
	while (*str && (*str == 32 || (*str >= 9 && *str <= 13)))
	{
		str++;
	}
	while (*str && (*str == '+' || *str == '-'))
	{
		if (*str == '-')
		{
			sign *= -1;
		}
		str++;
	}
	res = 0;
	while (*str && (*str >= '0' && *str <= '9'))
	{
		res = res * 10 + (*str - '0');
		str++;
	}
	return (sign * res);
}
/*
#include <stdio.h>

int main ()
{
	char	*s;
	s="   	---+++-+2354jdj97+gdi";
	printf("%d\n", ft_atoi(s));
}*/
