/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: olakhlil <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/28 16:18:23 by olakhlil          #+#    #+#             */
/*   Updated: 2025/08/28 16:58:19 by olakhlil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_power(int nb, int power)
{
	int	i;

	if (power == 0)
		return (1);
	if (power < 0)
	{
		return (0);
	}
	i = nb;
	while (power > 1)
	{
		nb *= i;
		power--;
	}
	return (nb);
}
/*
#include <stdio.h>

int main ()
{
	int	nb=10;
	int power=9;
	printf("res= %d\n", ft_iterative_power(nb, power));
}*/
